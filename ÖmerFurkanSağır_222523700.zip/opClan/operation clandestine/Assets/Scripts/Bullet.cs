using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Projectile : MonoBehaviour
{
    public int damage;
    public float lifetime;
    public GameObject impactEffect;

    private float spawnTime;

    private void OnEnable()
    {
        spawnTime = Time.time;
    }

    private void Update()
    {
        if (HasExpiredLifetime())
            DeactivateProjectile();
    }

    private bool HasExpiredLifetime()
    {
        return Time.time - spawnTime >= lifetime;
    }

    private void DeactivateProjectile()
    {
        gameObject.SetActive(false);
    }

    private void OnTriggerEnter(Collider other)
    {
        DealDamageToTarget(other.gameObject);
        CreateImpactEffect();
        DeactivateProjectile();
    }

    private void DealDamageToTarget(GameObject target)
    {
        if (target.CompareTag("Player"))
            target.GetComponent<PlayerCharacter>()?.TakeDamage(damage);
        else if (target.CompareTag("Enemy"))
            target.GetComponent<EnemyCharacter>()?.TakeDamage(damage);
    }

    private void CreateImpactEffect()
    {
        Instantiate(impactEffect, transform.position, Quaternion.identity);
    }
}

