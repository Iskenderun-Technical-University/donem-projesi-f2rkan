using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using System.Linq;

public class EnemyCharacter : MonoBehaviour
{
    public int health;
    public int maxHealth;
    public int scoreValue;

    public float movementSpeed;
    public float attackRange;
    public float yOffset;

    private List<Vector3> path;

    private Weapon weapon;
    private GameObject target;

    private void Start()
    {
        weapon = GetComponent<Weapon>();
        target = FindObjectOfType<PlayerCharacter>().gameObject;

        InvokeRepeating("UpdatePathToTarget", 0.0f, 0.5f);
    }

    private void Update()
    {
        float distanceToTarget = Vector3.Distance(transform.position, target.transform.position);

        if (distanceToTarget <= attackRange)
        {
            if (weapon.CanShoot())
                weapon.Shoot();
        }
        else
        {
            MoveTowardsTarget();
        }

        RotateTowardsTarget();
    }

    private void MoveTowardsTarget()
    {
        if (path.Count == 0)
            return;

        Vector3 targetPosition = path[0] + new Vector3(0, yOffset, 0);
        transform.position = Vector3.MoveTowards(transform.position, targetPosition, movementSpeed * Time.deltaTime);

        if (transform.position == targetPosition)
            path.RemoveAt(0);
    }

    private void UpdatePathToTarget()
    {
        NavMeshPath navMeshPath = new NavMeshPath();
        NavMesh.CalculatePath(transform.position, target.transform.position, NavMesh.AllAreas, navMeshPath);

        path = navMeshPath.corners.ToList();
    }

    private void RotateTowardsTarget()
    {
        Vector3 direction = (target.transform.position - transform.position).normalized;
        float angle = Mathf.Atan2(direction.x, direction.z) * Mathf.Rad2Deg;
        transform.eulerAngles = Vector3.up * angle;
    }

    public void TakeDamage(int damage)
    {
        health -= damage;

        if (health <= 0)
            Die();
    }

    private void Die()
    {
        GameManager.instance.AddScore(scoreValue);

        Destroy(gameObject);
    }
}

