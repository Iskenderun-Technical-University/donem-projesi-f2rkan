using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScoreManager : MonoBehaviour
{
    public int targetScore;
    public int currentScore;
    public bool isGamePaused;

    private static ScoreManager instance;

    void Initialize()
    {
        instance = this;
    }

    void StartGame()
    {
        Time.timeScale = 1.0f;    
    }

    void UpdateGame()
    {
        if (Input.GetButtonDown("Cancel"))
            TogglePause();
    }

    public static void TogglePause()
    {
        instance.isGamePaused = !instance.isGamePaused;
        Time.timeScale = instance.isGamePaused ? 0.0f : 1.0f;

        Cursor.lockState = instance.isGamePaused ? CursorLockMode.None : CursorLockMode.Locked;

        UIManager.instance.TogglePauseMenu(instance.isGamePaused);
    }

    public static void IncreaseScore(int score)
    {
        instance.currentScore += score;

        UIManager.instance.UpdateScore(instance.currentScore);

        if (instance.currentScore >= instance.targetScore)
            CompleteGame();
    }

    static void CompleteGame()
    {
        UIManager.instance.DisplayEndScreen(true, instance.currentScore);

        Time.timeScale = 0.0f;
        instance.isGamePaused = true;
        Cursor.lockState = CursorLockMode.None;
    }

    public static void FailGame()
    {
        UIManager.instance.DisplayEndScreen(false, instance.currentScore);

        Time.timeScale = 0.0f;
        instance.isGamePaused = true;
        Cursor.lockState = CursorLockMode.None;
    }
}

