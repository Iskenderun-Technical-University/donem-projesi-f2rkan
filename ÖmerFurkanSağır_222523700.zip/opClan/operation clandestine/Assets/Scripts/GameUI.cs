using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

public class UIManager : MonoBehaviour
{
    [Header("HUD")]
    public TextMeshProUGUI scoreTMP;
    public TextMeshProUGUI ammoTMP;
    public Image healthBarFillImage;

    [Header("Pause Menu")]
    public GameObject pauseMenuPanel;

    [Header("End Game Screen")]
    public GameObject endGameScreenPanel;
    public TextMeshProUGUI endGameHeaderText;
    public TextMeshProUGUI endGameScoreText;

    private static UIManager instance;

    void Awake()
    {
        instance = this;
    }

    public static void UpdateHealthBar(int currentHealth, int maxHealth)
    {
        instance.healthBarFillImage.fillAmount = (float)currentHealth / (float)maxHealth;
    }

    public static void UpdateScore(int score)
    {
        instance.scoreTMP.text = "Skor: " + score;
    }

    public static void UpdateAmmo(int currentAmmo, int maxAmmo)
    {
        instance.ammoTMP.text = "Mermi: " + currentAmmo + "/" + maxAmmo;
    }

    public static void TogglePauseMenu(bool isPaused)
    {
        instance.pauseMenuPanel.SetActive(isPaused);
    }

    public static void DisplayEndScreen(bool isWon, int score)
    {
        instance.endGameScreenPanel.SetActive(true);
        instance.endGameHeaderText.text = isWon ? "Kazandın!" : "Kaybettin!";
        instance.endGameHeaderText.color = isWon ? Color.green : Color.red;
        instance.endGameScoreText.text = "<b>Skor</b>\n" + score;
    }

    public static void ResumeGame()
    {
        GameManager.TogglePause();
    }

    public static void RestartGame()
    {
        SceneManager.LoadScene("Game");
    }

    public static void ReturnToMenu()
    {
        SceneManager.LoadScene("Menu");
    }
}

