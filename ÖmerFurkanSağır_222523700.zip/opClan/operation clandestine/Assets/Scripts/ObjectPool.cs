using System.Collections.Generic;
using UnityEngine;

public class ObjectPool : MonoBehaviour
{
    [SerializeField] private GameObject prefab;
    [SerializeField] private int initialCount;

    private List<GameObject> pooledObjects = new List<GameObject>();

    private void Start()
    {
        CreatePooledObjects(initialCount);
    }

    private void CreatePooledObjects(int count)
    {
        for (int i = 0; i < count; i++)
        {
            GameObject obj = Instantiate(prefab);
            obj.SetActive(false);
            pooledObjects.Add(obj);
        }
    }

    public GameObject GetPooledObject()
    {
        GameObject obj = FindInactiveObject();

        if (obj == null)
        {
            obj = CreatePooledObject();
        }

        obj.SetActive(true);
        return obj;
    }

    private GameObject FindInactiveObject()
    {
        return pooledObjects.Find(obj => !obj.activeSelf);
    }

    private GameObject CreatePooledObject()
    {
        GameObject obj = Instantiate(prefab);
        obj.SetActive(false);
        pooledObjects.Add(obj);
        return obj;
    }
}

