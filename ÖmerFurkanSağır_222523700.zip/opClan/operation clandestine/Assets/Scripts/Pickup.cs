using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum PickupItemType
{
    Health,
    Ammo
}

public class PickupItem : MonoBehaviour
{
    [SerializeField] private PickupItemType type;
    [SerializeField] private int value;
    [SerializeField] private AudioClip pickupSound;

    [Header("Bobbing")]
    [SerializeField] private float rotationSpeed;
    [SerializeField] private float bobbingSpeed;
    [SerializeField] private float bobbingHeight;

    private Vector3 startingPosition;
    private bool isBobbingUp;

    private void Start()
    {
        startingPosition = transform.position;
    }

    private void Update()
    {
        RotateItem();
        BobItem();
    }

    private void RotateItem()
    {
        transform.Rotate(Vector3.up, rotationSpeed * Time.deltaTime);
    }

    private void BobItem()
    {
        Vector3 offset = (isBobbingUp ? Vector3.up : Vector3.down) * (bobbingHeight / 2);
        transform.position = Vector3.MoveTowards(transform.position, startingPosition + offset, bobbingSpeed * Time.deltaTime);

        if (transform.position == startingPosition + offset)
            isBobbingUp = !isBobbingUp;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            PlayerController player = other.GetComponent<PlayerController>();

            switch (type)
            {
                case PickupItemType.Health:
                    player.AddHealth(value);
                    break;
                case PickupItemType.Ammo:
                    player.AddAmmo(value);
                    break;
            }

            AudioSource.PlayClipAtPoint(pickupSound, transform.position);
            Destroy(gameObject);
        }
    }
}

