using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public int currentHealth;
    public int maxHealth;

    public float moveSpeed;
    public float jumpForce;

    public float lookSensitivity;
    public float maxLookUpAngle;
    public float minLookDownAngle;
    private float cameraRotationX;

    private Camera playerCamera;
    private Rigidbody playerRigidbody;
    private Weapon weapon;

    private void Initialize()
    {
        playerCamera = Camera.main;
        playerRigidbody = GetComponent<Rigidbody>();
        weapon = GetComponent<Weapon>();

        Cursor.lockState = CursorLockMode.Locked;
    }

    private void StartGame()
    {
        GameUI.instance.UpdateHealthBar(currentHealth, maxHealth);
        GameUI.instance.UpdateScoreText(0);
        GameUI.instance.UpdateAmmoText(weapon.currentAmmo, weapon.maxAmmo);
    }

    private void UpdateGame()
    {
        if (GameManager.instance.IsGamePaused())
            return;

        MovePlayer();
        HandleJump();
        HandleShoot();
        HandleCameraLook();
    }

    private void MovePlayer()
    {
        float horizontalInput = Input.GetAxis("Horizontal") * moveSpeed;
        float verticalInput = Input.GetAxis("Vertical") * moveSpeed;

        Vector3 movementDirection = transform.right * horizontalInput + transform.forward * verticalInput;
        movementDirection.y = playerRigidbody.velocity.y;

        playerRigidbody.velocity = movementDirection;
    }

    private void HandleJump()
    {
        if (Input.GetButtonDown("Jump") && IsGrounded())
        {
            playerRigidbody.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
        }
    }

    private bool IsGrounded()
    {
        Ray groundRay = new Ray(transform.position, Vector3.down);
        float groundRayDistance = 1.1f;
        return Physics.Raycast(groundRay, groundRayDistance);
    }

    private void HandleShoot()
    {
        if (Input.GetButton("Fire1") && weapon.CanShoot())
        {
            weapon.Shoot();
        }
    }

    private void HandleCameraLook()
    {
        float mouseX = Input.GetAxis("Mouse X") * lookSensitivity;
        float mouseY = Input.GetAxis("Mouse Y") * lookSensitivity;

        transform.Rotate(Vector3.up, mouseX);

        cameraRotationX -= mouseY;
        cameraRotationX = Mathf.Clamp(cameraRotationX, minLookDownAngle, maxLookUpAngle);
        playerCamera.transform.localRotation = Quaternion.Euler(cameraRotationX, 0f, 0f);
    }

    public void TakeDamageFromEnemy(int damage)
    {
        currentHealth -= damage;
        currentHealth = Mathf.Clamp(currentHealth, 0, maxHealth);

        GameUI.instance.UpdateHealthBar(currentHealth, maxHealth);

        if (currentHealth <= 0)
        {
            PlayerDeath();
        }
    }

    private void PlayerDeath()
    {
        GameManager.instance.EndGame();
    }

    public void IncreaseAmmo(int amount)
    {
        weapon.currentAmmo += amount;
        weapon.currentAmmo = Mathf.Clamp(weapon.currentAmmo, 0, weapon.maxAmmo);

        GameUI.instance.UpdateAmmoText(weapon.currentAmmo, weapon.maxAmmo);
    }

    public void IncreaseHealth(int amount)
    {
        currentHealth += amount;
        currentHealth = Mathf.Clamp(currentHealth, 0, maxHealth);

        GameUI.instance.UpdateHealthBar(currentHealth, maxHealth);
    }
}

