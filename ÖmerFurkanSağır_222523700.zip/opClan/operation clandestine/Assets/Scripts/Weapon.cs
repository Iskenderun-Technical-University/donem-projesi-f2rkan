using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponController : MonoBehaviour
{
    private ObjectPool customBulletPool;
    private Transform customMuzzleTransform;

    private int customCurrentAmmoCount;
    private int customMaxAmmoCount;
    private bool customInfiniteAmmo;

    private float customBulletSpeed;

    private float customShootRate;
    private float customLastShootTime;
    private bool customIsPlayerWeapon;

    private AudioClip customShootSfx;
    private AudioSource customAudioSource;

    private void Start()
    {
        if (GetComponent<Player>())
            customIsPlayerWeapon = true;

        customAudioSource = GetComponent<AudioSource>();
    }

    public bool CanFire()
    {
        if (Time.time - customLastShootTime >= customShootRate)
        {
            if (customCurrentAmmoCount > 0 || customInfiniteAmmo)
                return true;
        }

        return false;
    }

    public void Fire()
    {
        customLastShootTime = Time.time;
        customCurrentAmmoCount--;

        if (customIsPlayerWeapon)
            GameUI.instance.UpdateAmmoText(customCurrentAmmoCount, customMaxAmmoCount);

        customAudioSource.PlayOneShot(customShootSfx);

        GameObject customBullet = customBulletPool.GetObject();

        customBullet.transform.position = customMuzzleTransform.position;
        customBullet.transform.rotation = customMuzzleTransform.rotation;

        customBullet.GetComponent<Rigidbody>().velocity = customMuzzleTransform.forward * customBulletSpeed;
    }
}

